# 9_3 — Пример: магазин на MongoDB, Node.js и Angular: ответы

**Курс:** 3813ICT, неделя 9
**Связанные файлы:** [конспект](9_3-crud-example-konspekt.md) · [поправки](9_3-crud-example-popravki.md) · [примеры](9_3-crud-example-primery.md) · [вопросы](9_3-crud-example-voprosy.md)

Под каждым ответом — пояснение и ссылки «Подробнее». Ссылка «← вопрос» возвращает к формулировке.

---

## A. Сервер

<a id="a-1"></a>

### 1. Почему сервер не стартует

**Ответ:** `dbName` нигде не объявлен → `ReferenceError`; в маршрут передаётся `ObjectID`, а импортирован `ObjectId` → ещё один `ReferenceError` (экспорта `ObjectID` в драйвере больше нет). Плюс у `main()` нет `.catch`.

**Подробнее:** [Конспект §2](9_3-crud-example-konspekt.md#s2) · [П-2](9_3-crud-example-popravki.md#p-2) · [← вопрос](9_3-crud-example-voprosy.md#q-1)

<a id="a-2"></a>

### 2. Маршрут, который не отвечает

**Ответ:** запрос будет висеть до таймаута: колбэки убраны из драйвера в версии 5.0, `toArray` возвращает Promise, а переданная функция не вызывается — `res.send` не выполняется.

```js
router.get('/', async (req, res) => {
  res.json(await getDb().collection('products').find({}).toArray());
});
```

**Подробнее:** [Конспект §3](9_3-crud-example-konspekt.md#s3) · [П-3](9_3-crud-example-popravki.md#p-3) · [← вопрос](9_3-crud-example-voprosy.md#q-2)

<a id="a-3"></a>

### 3. Два одновременных добавления

**Ответ:** оба запроса посчитают `0` и оба вставят товар — появятся дубликаты. Защита — уникальный индекс `createIndex({ id: 1 }, { unique: true })`: вторая вставка завершится ошибкой `11000`, маршрут поймает её и ответит `409`.

**Подробнее:** [Конспект §3.1](9_3-crud-example-konspekt.md#s3-1) · [П-4](9_3-crud-example-popravki.md#p-4) · [9_1, пример 3](9_1-mongodb-node-primery.md#ex-3) · [← вопрос](9_3-crud-example-voprosy.md#q-3)

<a id="a-4"></a>

### 4. `insertedCount`

**Ответ:** `num: undefined` — у результата `insertOne` нет `insertedCount`, только `acknowledged` и `insertedId`. `insertedCount` есть у `insertMany`. Клиент выведет «undefined new product … was added».

**Подробнее:** [Конспект §3.1](9_3-crud-example-konspekt.md#s3-1) · [9_1 §4](9_1-mongodb-node-konspekt.md#s4) · [← вопрос](9_3-crud-example-voprosy.md#q-4)

<a id="a-5"></a>

### 5. Счётчик всегда 400

**Ответ:** у `GET` нет тела, а в Express 5 `req.body` без разобранного тела — `undefined`, поэтому `!req.body` всегда истинно. В Express 4 с `body-parser` там был `{}`, и проверка проходила. Исправление — убрать проверку: `res.json({ count: await col().countDocuments({}) })`.

**Подробнее:** [Конспект §3.4](9_3-crud-example-konspekt.md#s3-4) · [П-5](9_3-crud-example-popravki.md#p-5) · [← вопрос](9_3-crud-example-voprosy.md#q-5)

<a id="a-6"></a>

### 6. Порядок маршрутов

**Ответ:** сработает `/:id` со значением `count`: `ObjectId.isValid('count')` — ложь, маршрут ответит `400` (или `404`). Express проверяет маршруты по порядку объявления, поэтому специальные адреса (`/count`, `/check-id/:id`) объявляют **раньше** `/:id`.

**Подробнее:** [Конспект §1.2](9_3-crud-example-konspekt.md#s1-2) · [П-1](9_3-crud-example-popravki.md#p-1) · [← вопрос](9_3-crud-example-voprosy.md#q-6)

<a id="a-7"></a>

### 7. Неверный `_id` и отсутствующий товар

**Ответ:** `new ObjectId('abc')` бросит исключение — без проверки клиент получит `500`. Правильно: `ObjectId.isValid` → `400`. Если `_id` верный, но документа нет, `findOneAndUpdate` вернёт `null` (у `updateOne` — `matchedCount: 0`) → `404`.

**Подробнее:** [Конспект §3.3](9_3-crud-example-konspekt.md#s3-3) · [П-7](9_3-crud-example-popravki.md#p-7) · [← вопрос](9_3-crud-example-voprosy.md#q-7)

---

## B. Клиент

<a id="a-8"></a>

### 8. Сервис

**Ответ:**

1. `<any>` отключает проверку типов ответа;
2. `productID` без типа — ошибка строгого режима;
3. полный адрес повторяется в каждом методе.

Плюс чтение идёт через `POST` с идентификатором в теле, а в REST это `GET /api/products/:id`.

**Подробнее:** [Конспект §4](9_3-crud-example-konspekt.md#s4) · [П-8](9_3-crud-example-popravki.md#p-8) · [← вопрос](9_3-crud-example-voprosy.md#q-8)

<a id="a-9"></a>

### 9. Проверка ID при вводе

**Ответ:** уйдут три запроса («1», «12», «123»), и ответы могут прийти не по порядку — на экране окажется результат для «12». Исправление:

- `debounceTime(400)` — ждать паузу в наборе;
- `distinctUntilChanged()` — не повторять ту же строку;
- `switchMap` — новый ввод отменяет прежний запрос.

**Подробнее:** [Конспект §6](9_3-crud-example-konspekt.md#s6) · [П-6](9_3-crud-example-popravki.md#p-6) · [← вопрос](9_3-crud-example-voprosy.md#q-9)

<a id="a-10"></a>

### 10. Подсказка свободного ID

**Ответ:** сервер может сразу вернуть `{ available, nextId: max + 1 }`. Нет, не гарантирует: между проверкой и отправкой формы номер может занять другой пользователь. Гарантию даёт уникальный индекс и ответ `409` при сохранении.

**Подробнее:** [Конспект §3.4](9_3-crud-example-konspekt.md#s3-4) · [П-6](9_3-crud-example-popravki.md#p-6) · [← вопрос](9_3-crud-example-voprosy.md#q-10)

<a id="a-11"></a>

### 11. Анимации

**Ответ:** `animate.enter` и `animate.leave` с обычными CSS-классами; пакет `@angular/animations` устарел с версии 20.2.

```html
@if (notice()) {
  <div animate.enter="fade-in" animate.leave="fade-out">{{ notice() }}</div>
}
```

Angular добавляет класс при появлении элемента и перед его удалением, дожидаясь конца анимации.

**Подробнее:** [Конспект §6](9_3-crud-example-konspekt.md#s6) · [П-9](9_3-crud-example-popravki.md#p-9) · [← вопрос](9_3-crud-example-voprosy.md#q-11)

<a id="a-12"></a>

### 12. Ошибки строгого режима и переключатель

**Ответ:**

- первая строка — `TS2322: Type 'null' is not assignable to type 'number'`;
- вторая — `TS2564`: поле без начального значения;
- третья **переключает** предупреждение: при второй подряд ошибке оно скроется. Нужно явно `iderrorshow = true` (или сигнал с текстом подсказки).

**Подробнее:** [Конспект §6](9_3-crud-example-konspekt.md#s6) · [П-9](9_3-crud-example-popravki.md#p-9) · [← вопрос](9_3-crud-example-voprosy.md#q-12)
