# 9_1 — MongoDB и Node.js: вопросы для самопроверки

**Курс:** 3813ICT, неделя 9
**Связанные файлы:** [конспект](9_1-mongodb-node-konspekt.md) · [поправки](9_1-mongodb-node-popravki.md) · [примеры](9_1-mongodb-node-primery.md) · [ответы](9_1-mongodb-node-otvety.md)

**Как работать:**

1. Отвечай по памяти, не открывая конспект. Для кода сначала предскажи результат.
2. Если не знаешь — так и отметь «не знаю»: это честнее и полезнее догадки.
3. После каждого раздела сверяйся с ответами (ссылка «→ ответ» под вопросом).
4. Вопросы, на которых ошибся, повтори через день.

---

## A. Драйвер и подключение

<a id="q-1"></a>

### 1. Драйвер

Что такое драйвер `mongodb` и чем работа через него отличается от работы в `mongosh`? Какая версия Node.js нужна драйверу 7.x?

[→ ответ](9_1-mongodb-node-otvety.md#a-1)

<a id="q-2"></a>

### 2. Что выведется и когда?

```js
async function main() {
  await client.connect();
  return 'done.';
}
main()
  .then(console.log('main...'))
  .finally(() => client.close());
```

[→ ответ](9_1-mongodb-node-otvety.md#a-2)

<a id="q-3"></a>

### 3. Вызов без `await`

В `main` вызывается `funOrders(client, collection)` без `await`, а в `finally` — `client.close()`. Что произойдёт с операциями внутри `funOrders`?

[→ ответ](9_1-mongodb-node-otvety.md#a-3)

<a id="q-4"></a>

### 4. `find` в драйвере

Что возвращает `collection.find({})` в драйвере? Как получить массив документов? Почему `find({}, { name: 1 })` не сработает как проекция и как записать правильно?

[→ ответ](9_1-mongodb-node-otvety.md#a-4)

---

## B. Колбэки, промисы, async/await

<a id="q-5"></a>

### 5. Колбэк в драйвере 7

Что произойдёт при выполнении этого кода с драйвером 7.x?

```js
collection.insertMany(docs, function (err, result) {
  console.log('inserted');
  client.close();
});
```

[→ ответ](9_1-mongodb-node-otvety.md#a-5)

<a id="q-6"></a>

### 6. Старые опции и экспорты

Что случится в каждой строке с драйвером 7.x?

```js
const ObjectId = require('mongodb').ObjectID;
const client = new MongoClient(url, { useNewUrlParser: true });
```

[→ ответ](9_1-mongodb-node-otvety.md#a-6)

<a id="q-7"></a>

### 7. Найди ошибку в цепочке

```js
col.find({}).toArray().then(function (err, result) {
  if (err) throw err;
  console.log(result);
});
```

Что попадёт в `err` и `result`? Чем закончится выполнение? Исправь.

[→ ответ](9_1-mongodb-node-otvety.md#a-7)

<a id="q-8"></a>

### 8. Исправь `awaitHeaven`

```js
const run = async function (client, col) {
  result = await col.insertMany(docs);
  result = await col.find({}).toArray();
  console.log(result);
  client.close();
};
```

Назови две проблемы и перепиши.

[→ ответ](9_1-mongodb-node-otvety.md#a-8)

---

## C. Сервер, ошибки, результаты

<a id="q-9"></a>

### 9. Когда закрывать соединение

Когда закрывают соединение в скрипте, а когда — на сервере Express? Почему нельзя подключаться и закрываться в каждом маршруте?

[→ ответ](9_1-mongodb-node-otvety.md#a-9)

<a id="q-10"></a>

### 10. Дубликат

Как ответить клиенту `409`, если товар с таким `id` уже есть? Почему проверка `countDocuments({ id })` перед `insertOne` не защищает от дубликатов?

[→ ответ](9_1-mongodb-node-otvety.md#a-10)

<a id="q-11"></a>

### 11. Не найдено

После `const r = await col.updateOne({ id: 99 }, { $set: { price: 10 } })` товара с `id: 99` нет. Что будет в `r` и какой код ответить клиенту?

[→ ответ](9_1-mongodb-node-otvety.md#a-11)

<a id="q-12"></a>

### 12. Порядок запуска

Почему сервер лучше запускать так: сначала `await connect()`, потом `app.listen()`? Что произойдёт, если `mongod` не запущен?

[→ ответ](9_1-mongodb-node-otvety.md#a-12)
