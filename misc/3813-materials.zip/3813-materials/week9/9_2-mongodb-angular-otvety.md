# 9_2 — MongoDB, Node.js и Angular: ответы

**Курс:** 3813ICT, неделя 9
**Связанные файлы:** [конспект](9_2-mongodb-angular-konspekt.md) · [поправки](9_2-mongodb-angular-popravki.md) · [примеры](9_2-mongodb-angular-primery.md) · [вопросы](9_2-mongodb-angular-voprosy.md)

Под каждым ответом — пояснение и ссылки «Подробнее». Ссылка «← вопрос» возвращает к формулировке.

---

## A. Сервер

<a id="a-1"></a>

### 1. Подключение в маршруте

**Ответ:** первый завершившийся запрос вызовет `client.close()`, и второй, который ещё выполняется, получит ошибку закрытого клиента. Правильно — подключиться один раз при старте сервера, запустить `listen` после подключения, во всех маршрутах использовать того же клиента и закрыть его только при остановке.

**Подробнее:** [Конспект §2.2](9_2-mongodb-angular-konspekt.md#s2-2) · [П-1](9_2-mongodb-angular-popravki.md#p-1) · [9_1, пример 2](9_1-mongodb-node-primery.md#ex-2) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-1)

<a id="a-2"></a>

### 2. Опасный маршрут

**Ответ:** изменить **что угодно**: отправив `{ "query": {}, "update": { "price": 0 } }`, обнулить цены всех товаров, а через `$set` записать любые поля. Безопасно: фильтр строит сервер — по `_id` из адреса; документ — только из разрешённых и проверенных полей; одна операция над одним документом (`findOneAndUpdate` или `updateOne` по `_id`).

**Подробнее:** [Конспект §2.3](9_2-mongodb-angular-konspekt.md#s2-3) · [П-4](9_2-mongodb-angular-popravki.md#p-4) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-2)

<a id="a-3"></a>

### 3. REST

**Ответ:** `POST /api/products`, `GET /api/products`, `PUT /api/products/:id`, `DELETE /api/products/:id` (и `GET /api/products/:id` для одного товара). Идентификатор — в адресе, действие — в методе.

**Подробнее:** [Конспект §2.3, таблица](9_2-mongodb-angular-konspekt.md#s2-3) · [П-3](9_2-mongodb-angular-popravki.md#p-3) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-3)

<a id="a-4"></a>

### 4. HTTPS локально

**Ответ:** нет: клиент говорит по HTTP с сервером, который ждёт HTTPS. Нужно, чтобы протокол совпадал: либо локально HTTP (или прокси `ng serve`), либо адрес `https://` в сервисе и сертификат, который браузер принял (открыть `https://localhost:3000` и подтвердить исключение).

**Подробнее:** [П-2](9_2-mongodb-angular-popravki.md#p-2) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-4)

---

## B. Сервис и контракт

<a id="a-5"></a>

### 5. Несовпадения

**Ответ:** на оба запроса сервер ответит `404`: маршруты объявлены для `POST`, а приходят `PUT` и `DELETE`. Второй аргумент `http.delete` — **опции** (заголовки, параметры), а не тело, поэтому `prod` на сервер не уйдёт. Идентификатор для удаления передают в адресе: `http.delete(`/api/products/${id}`)`.

**Подробнее:** [Конспект §4](9_2-mongodb-angular-konspekt.md#s4) · [П-6](9_2-mongodb-angular-popravki.md#p-6) · [Пример 3](9_2-mongodb-angular-primery.md#ex-3) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-5)

<a id="a-6"></a>

### 6. Подписка в сервисе

**Ответ:** компонент не получает Observable — значит, не узнает, когда операция закончилась, не обработает ошибку и не обновит экран. Сервис должен возвращать Observable: `create(p: ProdInput) { return this.http.post<ProdModel>(this.url, p); }`, а подписывается компонент.

**Подробнее:** [Конспект §4](9_2-mongodb-angular-konspekt.md#s4) · [5_4 П-4](../week5/5_4-http-requests-popravki.md#p-4) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-6)

<a id="a-7"></a>

### 7. Standalone

**Ответ:** `provideHttpClient()` и `provideRouter(routes)` в `app.config.ts`; компоненты не объявляют — они standalone и сами перечисляют в `imports` то, что используют (`FormsModule`, `RouterLink`, `RouterOutlet`).

**Подробнее:** [Конспект §3](9_2-mongodb-angular-konspekt.md#s3) · [П-5](9_2-mongodb-angular-popravki.md#p-5) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-7)

---

## C. Компоненты

<a id="a-8"></a>

### 8. Ошибки компиляции

**Ответ:**

- `prods: ProdModel[]` — TS2564: поле без начального значения (нужно `= []` или сигнал);
- `delete product._id` — TS2790: удалять можно только необязательные свойства;
- `JSON.parse(localStorage.getItem(...))` — TS2345: `getItem` может вернуть `null`, а `JSON.parse` ждёт строку.

**Подробнее:** [П-7](9_2-mongodb-angular-popravki.md#p-7) · [П-8](9_2-mongodb-angular-popravki.md#p-8) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-8)

<a id="a-9"></a>

### 9. `delete product._id`

**Ответ:** объект в списке тот же, что показан в таблице. После удаления `_id` у этой строки больше нет идентификатора — удалить или снова отредактировать её нельзя, пока список не загрузят заново.

**Подробнее:** [Конспект §5](9_2-mongodb-angular-konspekt.md#s5) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-9)

<a id="a-10"></a>

### 10. Как передать товар

**Ответ:** страница зависит от того, что кто-то раньше положил данные в хранилище; после очистки хранилища или при открытии ссылки в другом браузере данных нет, и `JSON.parse` вернёт `null`. Надёжно — передать `_id` в адресе (`/prod-edit/:id`), прочитать его через `ActivatedRoute` и загрузить товар с сервера.

**Подробнее:** [Конспект §6](9_2-mongodb-angular-konspekt.md#s6) · [П-8](9_2-mongodb-angular-popravki.md#p-8) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-10)

<a id="a-11"></a>

### 11. Обновление по старым полям

**Ответ:** если два товара совпадают по имени, цене и компании, `updateMany` изменит **оба**. Если товар уже изменили в другой вкладке, фильтр по старым значениям не совпадёт ни с чем, и обновление молча не произойдёт. Обновляют по `_id`.

**Подробнее:** [Конспект §6](9_2-mongodb-angular-konspekt.md#s6) · [П-8](9_2-mongodb-angular-popravki.md#p-8) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-11)

<a id="a-12"></a>

### 12. Удалили, а строка осталась

**Ответ:** компонент не узнал о завершении удаления (сервис подписался сам и ничего не вернул) и не изменил свой список. Правильно — подписаться на `remove(id)` в компоненте и в `next` убрать строку новым массивом: `prods.update(list => list.filter(p => p._id !== id))`.

**Подробнее:** [Конспект §5](9_2-mongodb-angular-konspekt.md#s5) · [П-7](9_2-mongodb-angular-popravki.md#p-7) · [← вопрос](9_2-mongodb-angular-voprosy.md#q-12)
