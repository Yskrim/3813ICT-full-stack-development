# 9_3 — Пример: магазин на MongoDB, Node.js и Angular: примеры использования

**Курс:** 3813ICT, неделя 9
**Связанные файлы:** [конспект](9_3-crud-example-konspekt.md) · [поправки](9_3-crud-example-popravki.md) · [вопросы](9_3-crud-example-voprosy.md) · [ответы](9_3-crud-example-otvety.md)

Примеры дополняют конспект теми частями магазина, которых в материале нет: главная со счётчиком, страница редактирования с неизменяемым `id` и проверка всех маршрутов одной командой. Сервер — роутер из [конспекта §3.5](9_3-crud-example-konspekt.md#s3-5), сервис — из [§4](9_3-crud-example-konspekt.md#s4).

> **Диаграммы.** В Obsidian mermaid рендерится сам. В VS Code нужно расширение **Markdown Preview Mermaid Support**.

---

<a id="ex-0"></a>

## Экраны и маршруты

| Экран | Действие | Метод сервиса | Маршрут |
|---|---|---|---|
| Главная | показать количество | `count()` | `GET /api/products/count` |
| Добавление | проверить ID при вводе | `checkId(id)` | `GET /api/products/check-id/:id` |
| Добавление | сохранить | `add(p)` | `POST /api/products` |
| Список | загрузить | `list()` | `GET /api/products` |
| Список | удалить | `remove(_id)` | `DELETE /api/products/:id` |
| Редактирование | загрузить | `get(_id)` | `GET /api/products/:id` |
| Редактирование | сохранить | `update(_id, p)` | `PUT /api/products/:id` |

| Пример | Что показывает |
|---|---|
| [1. Главная со счётчиком](#ex-1) | сигнал, состояния загрузки и ошибки, маршрут `count` |
| [2. Редактирование с неизменяемым ID](#ex-2) | `_id` из адреса, поле `id` только для чтения, `404` |
| [3. Проверка магазина одной командой](#ex-3) | семь маршрутов, `409` на дубликат, `nextId` |

---

<a id="ex-1"></a>

## Пример 1 — Главная со счётчиком

**Когда использовать:** на экране нужно одно значение с сервера, и важно честно показать три состояния: загружается, готово, ошибка. В материале именно этот экран не работал из-за проверки `req.body` в `GET` ([П-5](9_3-crud-example-popravki.md#p-5)).

**Где в конспекте:** [§1.3 Интерфейс](9_3-crud-example-konspekt.md#s1-3) · [§3.4 Счётчик](9_3-crud-example-konspekt.md#s3-4)

```ts
// ═════ src/app/home/home.component.ts ═════
import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ProductdataService } from '../services/productdata.service';

@Component({
  selector: 'app-home',
  imports: [RouterLink],
  template: `
    <h1>Product Store</h1>
    @if (count() === null && !error()) {
      <p>Загрузка…</p>
    } @else if (error()) {
      <p class="text-danger">{{ error() }}</p>
    } @else {
      <p>Товаров в магазине: <strong>{{ count() }}</strong></p>
      <a routerLink="/add" class="btn btn-primary">Добавить товар</a>
    }
  `,
})
export class HomeComponent implements OnInit {
  private proddata = inject(ProductdataService);
  protected count = signal<number | null>(null);   // null — ещё не загружено
  protected error = signal('');

  ngOnInit(): void {
    this.proddata.count().subscribe({
      next: ({ count }) => this.count.set(count),
      error: () => this.error.set('Не удалось получить количество товаров'),
    });
  }
}

// ═════ server/routes/products.js — маршрут (конспект §3.5) ═════
// router.get('/count', async (req, res) => {
//   res.json({ count: await col().countDocuments({}) });   // без проверки req.body — у GET его нет
// });
```

### Последовательность

1. Главная открывается — `count` равен `null`, показывается «Загрузка…».
2. `ngOnInit` отправляет `GET /api/products/count`.
3. Маршрут считает документы через `countDocuments` и отвечает `{ count: 3 }`.
4. Сигнал получает число — `@if` переключается на ветку с количеством.
5. Если сервер недоступен — ветка ошибки с понятным текстом.

```mermaid
sequenceDiagram
    autonumber
    participant H as HomeComponent
    participant S as ProductdataService
    participant R as GET /api/products/count
    participant M as MongoDB

    H->>H: count = null → «Загрузка…»
    H->>S: count()
    S->>R: GET
    R->>M: countDocuments {}
    M-->>R: 3
    R-->>H: count 3
    H->>H: показать «Товаров: 3»
```

---

<a id="ex-2"></a>

## Пример 2 — Редактирование с неизменяемым ID

**Когда использовать:** у записи есть поле, которое пользователь видит, но менять не должен (номер товара, логин). Защищать его нужно в двух местах: в форме — чтобы не вводить в заблуждение, на сервере — потому что форму можно обойти.

**Где в конспекте:** [§1.3 Интерфейс](9_3-crud-example-konspekt.md#s1-3) · [§3.3 Обновление](9_3-crud-example-konspekt.md#s3-3) · [§3.5 Исправленные маршруты](9_3-crud-example-konspekt.md#s3-5)

```ts
// ═════ src/app/app.routes.ts (фрагмент) ═════
// { path: 'update/:id', component: UpdateProductComponent }   // :id — это _id документа

// ═════ src/app/update-product/update-product.component.ts ═════
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { ProductInput, ProductdataService } from '../services/productdata.service';

@Component({
  selector: 'app-update-product',
  imports: [FormsModule],
  template: `
    @if (form(); as f) {
      <form (ngSubmit)="save(f)">
        <label>Product ID <input type="number" [value]="f.id" readonly></label>   <!-- только показ -->
        <label>Name <input name="name" [(ngModel)]="f.name" required></label>
        <label>Description <textarea name="description" [(ngModel)]="f.description"></textarea></label>
        <label>Price <input type="number" name="price" min="0" [(ngModel)]="f.price" required></label>
        <label>Units <input type="number" name="units" min="0" [(ngModel)]="f.units" required></label>
        <button type="submit" class="btn btn-primary">Save</button>
      </form>
    }
    @if (error()) { <p class="text-danger">{{ error() }}</p> }
  `,
})
export class UpdateProductComponent implements OnInit {
  private proddata = inject(ProductdataService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  private _id = '';
  protected form = signal<ProductInput | null>(null);   // null — пока не загружено
  protected error = signal('');

  ngOnInit(): void {
    this._id = this.route.snapshot.paramMap.get('id') ?? '';
    this.proddata.get(this._id).subscribe({
      next: ({ _id, ...fields }) => this.form.set(fields),   // копия без _id для формы
      error: (err: HttpErrorResponse) =>
        this.error.set(err.status === 404 ? 'Товар не найден' : 'Не удалось загрузить товар'),
    });
  }

  protected save(f: ProductInput): void {
    this.proddata.update(this._id, f).subscribe({
      next: () => this.router.navigate(['/list']),
      error: (err: HttpErrorResponse) =>
        this.error.set(err.status === 400 ? err.error.error : 'Не удалось сохранить'),
    });
  }
}

// ═════ server — почему id не изменится, даже если клиент его пришлёт ═════
// readFields(body) берёт только name, description, price, units (конспект §3.5),
// поэтому { $set: fields } физически не содержит id — поле защищено на сервере.
```

### Последовательность

1. Из списка пользователь переходит по ссылке `/update/66f1…` — `_id` в адресе.
2. Компонент берёт `_id` из маршрута и загружает товар `GET /api/products/66f1…`.
3. Найден — поля (без `_id`) попадают в сигнал `form`, форма показывается; поле ID только для чтения.
4. Не найден — сообщение «Товар не найден».
5. «Save» — `PUT /api/products/66f1…` с полями формы.
6. Сервер берёт из тела только разрешённые поля; даже если в теле будет `id`, он не попадёт в `$set`.
7. Успех — переход на список; ошибка проверки — текст сервера под формой.

```mermaid
sequenceDiagram
    autonumber
    actor U as Пользователь
    participant C as UpdateProductComponent
    participant R as /api/products/:id
    participant M as MongoDB

    U->>C: /update/66f1...
    C->>R: GET
    R->>M: findOne _id
    M-->>R: товар
    R-->>C: 200
    U->>C: меняет цену, Save
    C->>R: PUT, поля формы
    R->>R: readFields — id отброшен
    R->>M: findOneAndUpdate _id, $set
    R-->>C: 200, товар
    C->>C: navigate /list
```

---

<a id="ex-3"></a>

## Пример 3 — Проверка магазина одной командой

**Когда использовать:** перед демонстрацией или сдачей — убедиться, что все семь маршрутов отвечают как надо, включая дубликат и подсказку свободного ID. Сервер должен работать, уникальный индекс — создан при запуске.

**Где в конспекте:** [§3.5 Исправленные маршруты](9_3-crud-example-konspekt.md#s3-5) · [9_2, пример 3](9_2-mongodb-angular-primery.md#ex-3)

```js
// ═════ server/smoke-store.mjs — node smoke-store.mjs ═════
const API = 'http://localhost:3000/api/products';
const json = { 'Content-Type': 'application/json' };

async function call(method, path, body) {
  const res = await fetch(API + path, { method, headers: body ? json : undefined, body: body && JSON.stringify(body) });
  const text = await res.text();
  return { status: res.status, data: text ? JSON.parse(text) : null };
}
const check = (name, got, want) => console.log(`${got === want ? '✅' : '❌'} ${name}: ${got} (ожидали ${want})`);

const before = (await call('GET', '/count')).data.count;
const testId = 900000 + Math.floor(Math.random() * 1000);         // номер, которого точно нет
const product = { id: testId, name: 'Smoke item', description: 'test', price: 1.5, units: 2 };

const created = await call('POST', '', product);
check('POST создать', created.status, 201);
check('POST тот же id', (await call('POST', '', product)).status, 409);
check('POST без цены', (await call('POST', '', { ...product, id: testId + 1, price: undefined })).status, 400);

const hint = await call('GET', `/check-id/${testId}`);
check('check-id занят', hint.data.available, false);
check('nextId больше занятого', hint.data.nextId > testId, true);

check('count вырос на 1', (await call('GET', '/count')).data.count, before + 1);
check('GET список', (await call('GET', '')).status, 200);

const _id = created.data._id;
check('PUT изменить', (await call('PUT', `/${_id}`, { ...product, price: 3 })).status, 200);
check('PUT неверный _id', (await call('PUT', '/not-an-id', product)).status, 400);
check('DELETE удалить', (await call('DELETE', `/${_id}`)).status, 204);
check('DELETE повторно', (await call('DELETE', `/${_id}`)).status, 404);
check('count вернулся', (await call('GET', '/count')).data.count, before);
```

### Последовательность

1. Скрипт запоминает текущее количество товаров и выбирает номер, которого нет в базе.
2. Создаёт товар (`201`), пытается создать его повторно (`409` — сработал уникальный индекс) и без цены (`400`).
3. Проверяет подсказку: номер занят, `nextId` больше него.
4. Убеждается, что счётчик вырос на один и список загружается.
5. Изменяет товар (`200`), проверяет отказ на неверный `_id` (`400`).
6. Удаляет товар (`204`), повторное удаление даёт `404`, счётчик вернулся к исходному.

```mermaid
flowchart LR
    A["count до"] --> B["POST 201"]
    B --> C["POST дубль 409"]
    C --> D["POST без цены 400"]
    D --> E["check-id: занят, nextId"]
    E --> F["count +1"]
    F --> G["PUT 200 / 400"]
    G --> H["DELETE 204 / 404"]
    H --> I["count как до"]
```
