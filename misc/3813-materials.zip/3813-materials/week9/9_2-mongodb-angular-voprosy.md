# 9_2 — MongoDB, Node.js и Angular: вопросы для самопроверки

**Курс:** 3813ICT, неделя 9
**Связанные файлы:** [конспект](9_2-mongodb-angular-konspekt.md) · [поправки](9_2-mongodb-angular-popravki.md) · [примеры](9_2-mongodb-angular-primery.md) · [ответы](9_2-mongodb-angular-otvety.md)

**Как работать:**

1. Отвечай по памяти, не открывая конспект. Для кода сначала предскажи результат.
2. Если не знаешь — так и отметь «не знаю»: это честнее и полезнее догадки.
3. После каждого раздела сверяйся с ответами (ссылка «→ ответ» под вопросом).
4. Вопросы, на которых ошибся, повтори через день.

---

## A. Сервер

<a id="q-1"></a>

### 1. Подключение в маршруте

Каждый маршрут делает `await client.connect()` в начале и `client.close()` в конце, а `client` общий. Что произойдёт, если два запроса придут одновременно? Как правильно?

[→ ответ](9_2-mongodb-angular-otvety.md#a-1)

<a id="q-2"></a>

### 2. Опасный маршрут

```js
exports.update = async (req, res) => {
  const r = await col.updateMany(req.body.query, { $set: req.body.update });
  res.send(r);
};
```

Что может сделать любой клиент, отправив запрос на этот маршрут? Как должен выглядеть безопасный вариант?

[→ ответ](9_2-mongodb-angular-otvety.md#a-2)

<a id="q-3"></a>

### 3. REST

Перепиши маршруты `POST /productInsert`, `GET /productFind`, `POST /productUpdate`, `POST /productDelete` в стиле REST. Где должен быть идентификатор товара?

[→ ответ](9_2-mongodb-angular-otvety.md#a-3)

<a id="q-4"></a>

### 4. HTTPS локально

Сервер запущен через `https.createServer` с самоподписанным сертификатом, а сервис Angular обращается к `http://localhost:3000`. Дойдут ли запросы? Что нужно, чтобы работало?

[→ ответ](9_2-mongodb-angular-otvety.md#a-4)

---

## B. Сервис и контракт

<a id="q-5"></a>

### 5. Найди несовпадения

Сервер: `app.post('/productUpdate', ...)`, `app.post('/productDelete', ...)`.
Сервис: `this.http.put(url + 'productUpdate', data)`, `this.http.delete(url + 'productDelete', prod)`.

Что ответит сервер на каждый запрос? Что не так со вторым аргументом `http.delete`?

[→ ответ](9_2-mongodb-angular-otvety.md#a-5)

<a id="q-6"></a>

### 6. Подписка в сервисе

Почему метод сервиса `productInsert(prod) { this.http.post(...).subscribe(...) }` неудобен компоненту? Как переписать?

[→ ответ](9_2-mongodb-angular-otvety.md#a-6)

<a id="q-7"></a>

### 7. Standalone

Чем в standalone-проекте заменяют `HttpClientModule`, `AppRoutingModule` и объявление компонентов в `declarations`?

[→ ответ](9_2-mongodb-angular-otvety.md#a-7)

---

## C. Компоненты

<a id="q-8"></a>

### 8. Ошибки компиляции

Почему эти строки не компилируются в строгом режиме?

```ts
prods: ProdModel[];
delete product._id;              // _id в интерфейсе обязательный
prod = JSON.parse(localStorage.getItem('product'));
```

[→ ответ](9_2-mongodb-angular-otvety.md#a-8)

<a id="q-9"></a>

### 9. `delete product._id`

Кроме ошибки компиляции, чем плохо удалять `_id` у объекта из списка перед переходом на страницу редактирования?

[→ ответ](9_2-mongodb-angular-otvety.md#a-9)

<a id="q-10"></a>

### 10. Как передать товар на страницу редактирования

Почему передавать товар через localStorage ненадёжно? Как сделать, чтобы страница редактирования работала и после F5, и по прямой ссылке?

[→ ответ](9_2-mongodb-angular-otvety.md#a-10)

<a id="q-11"></a>

### 11. Обновление по старым полям

Страница редактирования отправляет исходную версию товара (имя, цена, компания) как фильтр `updateMany`. Что пойдёт не так, если в базе два одинаковых товара? А если товар успели изменить в другой вкладке?

[→ ответ](9_2-mongodb-angular-otvety.md#a-11)

<a id="q-12"></a>

### 12. Удалили, а строка осталась

После нажатия «Delete» товар удалён в базе, но строка осталась в таблице. Почему так бывает и как обновить список без повторной загрузки?

[→ ответ](9_2-mongodb-angular-otvety.md#a-12)
