# 9_1 — MongoDB и Node.js: ответы

**Курс:** 3813ICT, неделя 9
**Связанные файлы:** [конспект](9_1-mongodb-node-konspekt.md) · [поправки](9_1-mongodb-node-popravki.md) · [примеры](9_1-mongodb-node-primery.md) · [вопросы](9_1-mongodb-node-voprosy.md)

Под каждым ответом — пояснение и ссылки «Подробнее». Ссылка «← вопрос» возвращает к формулировке.

---

## A. Драйвер и подключение

<a id="a-1"></a>

### 1. Драйвер

**Ответ:** npm-пакет, через который код Node.js подключается к `mongod` и выполняет те же операции, что в `mongosh`. Отличие: каждая операция асинхронная и возвращает Promise, результат получают через `await` или `then`. Драйвер 7.x требует Node.js 20.19 или новее.

**Подробнее:** [Конспект §1](9_1-mongodb-node-konspekt.md#s1) · [П-1](9_1-mongodb-node-popravki.md#p-1) · [← вопрос](9_1-mongodb-node-voprosy.md#q-1)

<a id="a-2"></a>

### 2. Что выведется и когда

**Ответ:** `main...` — сразу, ещё до подключения; `done.` не выведется никогда. В `then` передан не обработчик, а результат вызова `console.log` (`undefined`). Правильно: `.then((result) => console.log(result))`.

**Подробнее:** [Конспект §3](9_1-mongodb-node-konspekt.md#s3) · [П-2](9_1-mongodb-node-popravki.md#p-2) · [← вопрос](9_1-mongodb-node-voprosy.md#q-2)

<a id="a-3"></a>

### 3. Вызов без `await`

**Ответ:** `funOrders` только запустит операции и сразу вернётся; `main` завершится, `finally` закроет клиента, и незавершённые операции упадут с ошибкой о закрытом клиенте. Нужно `await funOrders(collection)`.

**Подробнее:** [Конспект §3](9_1-mongodb-node-konspekt.md#s3) · [П-2](9_1-mongodb-node-popravki.md#p-2) · [← вопрос](9_1-mongodb-node-voprosy.md#q-3)

<a id="a-4"></a>

### 4. `find` в драйвере

**Ответ:** курсор. Массив — `await collection.find({}).toArray()`. Второй аргумент `find` в драйвере — объект **опций**, поэтому проекцию пишут так: `find({}, { projection: { name: 1 } })` (или цепочкой `.project({ name: 1 })`).

**Подробнее:** [Конспект §4](9_1-mongodb-node-konspekt.md#s4) · [← вопрос](9_1-mongodb-node-voprosy.md#q-4)

---

## B. Колбэки, промисы, async/await

<a id="a-5"></a>

### 5. Колбэк в драйвере 7

**Ответ:** документы вставятся (если сервер доступен), но колбэк **не будет вызван никогда**: поддержку колбэков убрали в драйвере 5.0, метод возвращает Promise. `inserted` не выведется, `client.close()` не вызовется, процесс «зависнет».

**Подробнее:** [Конспект §5.1](9_1-mongodb-node-konspekt.md#s5-1) · [П-3](9_1-mongodb-node-popravki.md#p-3) · [← вопрос](9_1-mongodb-node-voprosy.md#q-5)

<a id="a-6"></a>

### 6. Старые опции и экспорты

**Ответ:** в первой строке `ObjectId` станет `undefined` — экспорт `ObjectID` удалён, есть только `ObjectId`. Вторая строка бросит `MongoParseError: option usenewurlparser is not supported`. Правильно: `const { MongoClient, ObjectId } = require('mongodb'); new MongoClient(url)`.

**Подробнее:** [П-4](9_1-mongodb-node-popravki.md#p-4) · [← вопрос](9_1-mongodb-node-voprosy.md#q-6)

<a id="a-7"></a>

### 7. Ошибка в цепочке

**Ответ:** обработчик `then` получает один аргумент, поэтому массив документов попадёт в `err`, а `result` будет `undefined`. Непустой массив истинен — `throw err` бросит документы как ошибку, получится необработанное отклонение.

```js
col.find({}).toArray()
  .then((docs) => console.log(docs))
  .catch((err) => console.error(err));
```

**Подробнее:** [Конспект §5.2](9_1-mongodb-node-konspekt.md#s5-2) · [П-5](9_1-mongodb-node-popravki.md#p-5) · [← вопрос](9_1-mongodb-node-voprosy.md#q-7)

<a id="a-8"></a>

### 8. Исправь `awaitHeaven`

**Ответ:** `result` не объявлена (в строгом режиме `ReferenceError`); при ошибке любой операции `client.close()` не выполнится.

```js
const run = async function (client, col) {
  try {
    await col.insertMany(docs);
    const all = await col.find({}).toArray();
    console.log(all);
  } finally {
    await client.close();
  }
};
```

**Подробнее:** [Конспект §5.3](9_1-mongodb-node-konspekt.md#s5-3) · [П-6](9_1-mongodb-node-popravki.md#p-6) · [← вопрос](9_1-mongodb-node-voprosy.md#q-8)

---

## C. Сервер, ошибки, результаты

<a id="a-9"></a>

### 9. Когда закрывать соединение

**Ответ:** в скрипте — в `finally`, когда все операции завершены. На сервере — один раз при остановке. `MongoClient` держит пул соединений и рассчитан на переиспользование. Подключение на каждый запрос медленное, а закрытие в одном маршруте ломает запросы, которые в это же время выполняются в других.

**Подробнее:** [Конспект §6](9_1-mongodb-node-konspekt.md#s6) · [Пример 2](9_1-mongodb-node-primery.md#ex-2) · [← вопрос](9_1-mongodb-node-voprosy.md#q-9)

<a id="a-10"></a>

### 10. Дубликат

**Ответ:** создать уникальный индекс `createIndex({ id: 1 }, { unique: true })`, а при вставке ловить `MongoServerError` с `code === 11000` и отвечать `409`. Проверка `countDocuments` перед вставкой — два отдельных запроса: два одновременных клиента оба увидят «нет» и оба вставят. Уникальный индекс проверяет и вставляет одной операцией базы.

**Подробнее:** [Пример 3](9_1-mongodb-node-primery.md#ex-3) · [Конспект §6](9_1-mongodb-node-konspekt.md#s6) · [← вопрос](9_1-mongodb-node-voprosy.md#q-10)

<a id="a-11"></a>

### 11. Не найдено

**Ответ:** `r.matchedCount === 0` (и `modifiedCount === 0`) — ошибки нет, операция просто ничего не нашла. Клиенту — `404`.

**Подробнее:** [Конспект §4](9_1-mongodb-node-konspekt.md#s4) · [Пример 3](9_1-mongodb-node-primery.md#ex-3) · [← вопрос](9_1-mongodb-node-voprosy.md#q-11)

<a id="a-12"></a>

### 12. Порядок запуска

**Ответ:** так сервер не примет запросы раньше, чем готова база: маршруты сразу могут пользоваться `getDb()`. Если `mongod` не запущен, `connect()` отклонится (ошибка выбора сервера), и `start()` завершит процесс с понятным сообщением, вместо сервера, который отвечает `500` на каждый запрос.

**Подробнее:** [Пример 2](9_1-mongodb-node-primery.md#ex-2) · [← вопрос](9_1-mongodb-node-voprosy.md#q-12)
